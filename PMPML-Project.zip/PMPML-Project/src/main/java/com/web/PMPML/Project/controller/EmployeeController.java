package com.web.PMPML.Project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.web.PMPML.Project.model.Employee;
import com.web.PMPML.Project.repo.EmployeeRepo;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/employee")
public class EmployeeController {
    
    @Autowired
    private EmployeeRepo employeeRepo;


    @GetMapping("/get")
    @ResponseBody
    public List<Employee> show(){
        List<Employee> list=employeeRepo.findAll();
        return list;
    }

    @GetMapping("/getemployee/{employee_id}")
    @ResponseBody
    public Employee show(@PathVariable("employee_id")int employee_id){
        Employee list=employeeRepo.findById(employee_id).get();
        return list;
    }
    
    @PostMapping("/saveemployee")
    @ResponseBody
    public String saveEmployee(@RequestBody Employee employee){
       employeeRepo.save(employee);
       return "save...";
    }

    @PutMapping("/updateemployee/{employee_id}")
    @ResponseBody
    public Employee updateEmployee(@RequestBody Employee employee,@PathVariable("employee_id") int employee_id){
        Employee emp=employeeRepo.findById(employee_id).get();
        emp.setEmployee_name(employee.getEmployee_name());
        emp.setEmployee_email(employee.getEmployee_email());
        emp.setEmployee_gender(employee.getEmployee_gender());
        emp.setEmployee_dob(employee.getEmployee_dob());
        emp.setEmployee_address(employee.getEmployee_address());
        emp.setEmployee_phone(employee.getEmployee_phone());
         employeeRepo.save(emp);
       
         return emp;
    }

    @DeleteMapping("/deleteemployee/{employee_id}")
   @ResponseBody
    public void deleteEmployee(@PathVariable("employee_id") int employee_id){
     
           employeeRepo.deleteById(employee_id);
         
    }
    }
